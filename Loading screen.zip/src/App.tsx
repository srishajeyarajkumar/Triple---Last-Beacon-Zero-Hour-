import { useEffect, useState } from "react";

type Phase = "intro" | "loading" | "meadow";

function Cloud({
  className,
  delay = "0s",
}: {
  className: string;
  delay?: string;
}) {
  return (
    <div className={`cloud ${className}`} style={{ animationDelay: delay }}>
      <span />
      <span />
      <span />
    </div>
  );
}

function Sparkle({
  className,
  delay = "0s",
}: {
  className: string;
  delay?: string;
}) {
  return (
    <span
      className={`sparkle ${className}`}
      style={{ animationDelay: delay }}
      aria-hidden="true"
    >
      <svg viewBox="0 0 24 24">
        <path d="M12 1.8c.6 5.8 4.4 9.6 10.2 10.2-5.8.6-9.6 4.4-10.2 10.2C11.4 16.4 7.6 12.6 1.8 12 7.6 11.4 11.4 7.6 12 1.8Z" />
      </svg>
    </span>
  );
}

function AmbientScene() {
  return (
    <div className="ambient-scene" aria-hidden="true">
      <div className="ambient-glow glow-one" />
      <div className="ambient-glow glow-two" />
      <Cloud className="cloud-one" />
      <Cloud className="cloud-two" delay="-5s" />
      <Sparkle className="sparkle-one" />
      <Sparkle className="sparkle-two" delay="-1.6s" />
      <Sparkle className="sparkle-three" delay="-3s" />
      <span className="quiet-star star-one" />
      <span className="quiet-star star-two" />
      <span className="quiet-star star-three" />
    </div>
  );
}

function Crest() {
  return (
    <div className="crest" aria-hidden="true">
      <div className="crest-orbit" />
      <div className="crest-moon" />
      <span className="crest-star" />
    </div>
  );
}

function IntroScreen({ onEnter }: { onEnter: () => void }) {
  return (
    <main className="screen intro-screen">
      <AmbientScene />
      <section className="intro-card">
        <Crest />
        <p className="eyebrow">A quiet world beyond the clouds</p>
        <h1>
          Dreamy <span>Meadows</span>
        </h1>
        <p className="intro-copy">
          Wander slowly through a world of hidden paths, soft light, and stories
          waiting to be found.
        </p>
        <button className="primary-button" type="button" onClick={onEnter}>
          <span>Enter the meadow</span>
          <svg viewBox="0 0 20 20" aria-hidden="true">
            <path d="m7.5 4.5 5 5.5-5 5.5" />
          </svg>
        </button>
        <p className="small-note">Best experienced with sound</p>
      </section>
      <div className="horizon horizon-back" aria-hidden="true" />
      <div className="horizon horizon-front" aria-hidden="true" />
    </main>
  );
}

function LoadingScreen({ progress }: { progress: number }) {
  return (
    <main className={`screen loading-screen ${progress === 100 ? "complete" : ""}`}>
      <AmbientScene />
      <section className="loading-content" aria-live="polite">
        <div className="wisp" aria-hidden="true">
          <span className="wisp-core" />
          <span className="wisp-orbit orbit-one" />
          <span className="wisp-orbit orbit-two" />
        </div>
        <p className="eyebrow">Crossing the threshold</p>
        <h1>Preparing your path</h1>
        <p className="loading-detail">
          {progress < 38
            ? "Gathering the morning light"
            : progress < 72
              ? "Opening hidden pathways"
              : progress < 100
                ? "Letting the meadow wake"
                : "The way is open"}
        </p>

        <div className="loader-wrap">
          <div className="game-progress">
            <div className="runner-stage" aria-hidden="true">
              <div className="runner-trail" style={{ width: `${progress}%` }} />
              <div
                className="pixel-runner"
                style={{
                  left: `calc(${Math.min(97, Math.max(3, progress))}% - 14px)`,
                }}
              >
                <span className="pixel-hair" />
                <span className="pixel-face">
                  <i className="pixel-eye pixel-eye-one" />
                  <i className="pixel-eye pixel-eye-two" />
                  <i className="pixel-blush" />
                </span>
                <span className="pixel-body" />
                <span className="pixel-arm" />
                <span className="pixel-leg pixel-leg-one" />
                <span className="pixel-leg pixel-leg-two" />
              </div>
              <span className="pixel-flower flower-obstacle-one">
                <i /><i /><i /><i /><b />
              </span>
              <span className="pixel-flower flower-obstacle-two">
                <i /><i /><i /><i /><b />
              </span>
              <span className="pixel-flower flower-obstacle-three">
                <i /><i /><i /><i /><b />
              </span>
            </div>
            <div className="progress-track">
              <div
                className="progress-fill"
                style={{ width: `${progress}%` }}
                role="progressbar"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={progress}
                aria-label="Preparing the meadow"
              >
                <span />
              </div>
            </div>
          </div>
          <div className="progress-meta">
            <span>Loading your world</span>
            <strong>{String(progress).padStart(2, "0")}%</strong>
          </div>
        </div>
      </section>
      <div className="horizon horizon-back" aria-hidden="true" />
      <div className="horizon horizon-front" aria-hidden="true" />
    </main>
  );
}

function MeadowScreen({ onRestart }: { onRestart: () => void }) {
  return (
    <main className="screen meadow-screen">
      <AmbientScene />
      <section className="meadow-content">
        <p className="eyebrow">Chapter one</p>
        <h1>The meadow remembers you.</h1>
        <p>Follow the light. There is something waiting beyond the ridge.</p>
        <button className="text-button" type="button">
          Begin the journey
          <span aria-hidden="true">—</span>
        </button>
        <button className="restart-button" type="button" onClick={onRestart}>
          Return to entrance
        </button>
      </section>
      <div className="sun-disc" aria-hidden="true" />
      <div className="horizon horizon-back" aria-hidden="true" />
      <div className="horizon horizon-front" aria-hidden="true" />
      <div className="grass grass-one" aria-hidden="true" />
      <div className="grass grass-two" aria-hidden="true" />
      <div className="grass grass-three" aria-hidden="true" />
    </main>
  );
}

export default function App() {
  const [phase, setPhase] = useState<Phase>("intro");
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (phase !== "loading") return;

    const startedAt = performance.now();
    let resourcesReady = document.readyState === "complete";
    let fontsReady = !document.fonts;
    const markResourcesReady = () => {
      resourcesReady = true;
    };

    window.addEventListener("load", markResourcesReady);
    document.fonts?.ready.then(() => {
      fontsReady = true;
    });

    const interval = window.setInterval(() => {
      const elapsed = performance.now() - startedAt;
      const timedProgress = Math.min(100, Math.floor(elapsed / 65));
      const nextProgress =
        timedProgress >= 94 && (!resourcesReady || !fontsReady)
          ? 94
          : timedProgress;
      setProgress(nextProgress);
    }, 80);

    return () => {
      window.clearInterval(interval);
      window.removeEventListener("load", markResourcesReady);
    };
  }, [phase]);

  useEffect(() => {
    if (phase !== "loading" || progress < 100) return;
    const timer = window.setTimeout(() => setPhase("meadow"), 850);
    return () => window.clearTimeout(timer);
  }, [phase, progress]);

  if (phase === "intro") {
    return (
      <IntroScreen
        onEnter={() => {
          setProgress(0);
          setPhase("loading");
        }}
      />
    );
  }

  if (phase === "loading") return <LoadingScreen progress={progress} />;
  return (
    <MeadowScreen
      onRestart={() => {
        setProgress(0);
        setPhase("intro");
      }}
    />
  );
}
